#include <DHT.h>

#define DHTPIN 4
#define DHTTYPE DHT11
#define BUZZER_PIN 5

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  Serial.println("ESP32 Smart Temperature Monitoring");
  Serial.println("----------------------------------");
}

void loop() {
  delay(2000);

  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("Sensor reading failed. Check wiring.");
    return;
  }

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" C");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");

  if (temperature > 35.0) {
    digitalWrite(BUZZER_PIN, HIGH);
    Serial.println("Alert: High temperature!");
  } else {
    digitalWrite(BUZZER_PIN, LOW);
    Serial.println("Status: Normal");
  }

  Serial.println();
}
